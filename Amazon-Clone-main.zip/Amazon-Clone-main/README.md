# Amazon-Clone
Create Amazon Clone Using HTML, CSS and JavaScript | Frontend Project
